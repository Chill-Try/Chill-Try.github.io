@echo off
call :isAdmin

set RUNDIR=%~dp0
set KEY=HKU\.DEFAULT\Control Panel\Cursors
REG export "%KEY%" "%RUNDIR:~0,-1%\DefaultCursors.reg"
REG add "%KEY%" /v "AppStarting" /t REG_EXPAND_SZ /d "%%SYSTEMROOT%%\Cursors\Custom\start1.ani" /f
REG add "%KEY%" /v "Arrow" /t REG_EXPAND_SZ /d "%%SYSTEMROOT%%\Cursors\Custom\arrow.cur" /f
REG add "%KEY%" /v "Crosshair" /t REG_EXPAND_SZ /d "%%SYSTEMROOT%%\Cursors\Custom\cross.cur" /f
REG add "%KEY%" /v "Hand" /t REG_EXPAND_SZ /d "%%SYSTEMROOT%%\Cursors\Custom\hand.cur" /f
REG add "%KEY%" /v "Help" /t REG_EXPAND_SZ /d "%%SYSTEMROOT%%\Cursors\Custom\help.cur" /f
REG add "%KEY%" /v "IBeam" /t REG_EXPAND_SZ /d "%%SYSTEMROOT%%\Cursors\Custom\text.cur" /f
REG add "%KEY%" /v "No" /t REG_EXPAND_SZ /d "%%SYSTEMROOT%%\Cursors\Custom\no.cur" /f
REG add "%KEY%" /v "NWPen" /t REG_EXPAND_SZ /d "%%SYSTEMROOT%%\Cursors\Custom\pen.cur" /f
REG add "%KEY%" /v "SizeAll" /t REG_EXPAND_SZ /d "%%SYSTEMROOT%%\Cursors\Custom\move.cur" /f
REG add "%KEY%" /v "SizeNESW" /t REG_EXPAND_SZ /d "%%SYSTEMROOT%%\Cursors\Custom\diag2.cur" /f
REG add "%KEY%" /v "SizeNS" /t REG_EXPAND_SZ /d "%%SYSTEMROOT%%\Cursors\Custom\vert.cur" /f
REG add "%KEY%" /v "SizeNWSE" /t REG_EXPAND_SZ /d "%%SYSTEMROOT%%\Cursors\Custom\diag1.cur" /f
REG add "%KEY%" /v "SizeWE" /t REG_EXPAND_SZ /d "%%SYSTEMROOT%%\Cursors\Custom\hori.cur" /f
REG add "%KEY%" /v "UpArrow" /t REG_EXPAND_SZ /d "%%SYSTEMROOT%%\Cursors\Custom\select.cur" /f
REG add "%KEY%" /v "Wait" /t REG_EXPAND_SZ /d "%%SYSTEMROOT%%\Cursors\Custom\wait1.ani" /f
REG add "%KEY%" /v "Pin" /t REG_EXPAND_SZ /d "%%SYSTEMROOT%%\Cursors\Custom\pin.cur" /f
REG add "%KEY%" /v "Person" /t REG_EXPAND_SZ /d "%%SYSTEMROOT%%\Cursors\Custom\person.cur" /f
exit

:isAdmin
REG query "HKU\S-1-5-19\Environment" >nul
if not %ERRORLEVEL% equ 0 (
	cls & echo Please run with administrator rights.
	timeout /t 3 >nul
	exit
)
goto :EOF
