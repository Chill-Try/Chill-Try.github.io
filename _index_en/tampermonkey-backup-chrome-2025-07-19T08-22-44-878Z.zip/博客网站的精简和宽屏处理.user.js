// ==UserScript==
// @name         博客网站的精简和宽屏处理
// @namespace    https://github.com/liehuoe/tampermonkey_script
// @version      0.2.3
// @author       liehuoe
// @description  自用
// @license      GPLv3
// @match        https://*.zhihu.com/*
// @match        https://*.csdn.net/*
// @match        https://*.jianshu.com/*
// @match        https://*.juejin.cn/*
// @match        https://*.51cto.com/*
// @match        http://*.360doc.com/*
// @match        https://*.bilibili.com/*
// @match        https://*.segmentfault.com/*
// @icon         data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBzdGFuZGFsb25lPSJubyI/PjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+PHN2ZyB0PSIxNzAxNDAzMDEwODAzIiBjbGFzcz0iaWNvbiIgdmlld0JveD0iMCAwIDEwMjQgMTAyNCIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHAtaWQ9Ijg1NTgiIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iMjU2IiBoZWlnaHQ9IjI1NiI+PHBhdGggZD0iTTMyIDY0TDk2IDB2MTAyNGwtNjQtNjRoOTI2LjQ3NmwtNjQgNjRWMGw2NCA2NEgzMnpNOTU4LjQ3NiAwdjEwMjRIMzJWMGg5MjYuNDc2eiIgcC1pZD0iODU1OSIgZmlsbD0iI2Q0MjM3YSI+PC9wYXRoPjxwYXRoIGQ9Ik0xNzguMjg2IDIxMC4yODZsNjQtNjR2MjkyLjU3MWwtNjQtNjRIODEyLjE5bC02NCA2NFYxNDYuMjg2bDY0IDY0SDE3OC4yODZ6IG02MzMuOTA0LTY0djI5Mi41NzFIMTc4LjI4NlYxNDYuMjg2SDgxMi4xOXpNMTc4LjI4NiA3NDYuNjY3bDY0LTY0djE5NS4wNDdsLTY0LTY0SDgxMi4xOWwtNjQgNjRWNjgyLjY2N2w2NCA2NEgxNzguMjg2eiBtNjMzLjkwNC02NHYxOTUuMDQ3SDE3OC4yODZWNjgyLjY2N0g4MTIuMTl6TTc4Ny44MSA1OTIuNzYyYzE3LjY3MyAwIDMyLTE0LjMyNyAzMi0zMiAwLTE3LjY3My0xNC4zMjctMzItMzItMzJIMjAyLjY2N2MtMTcuNjczIDAtMzIgMTQuMzI3LTMyIDMyIDAgMTcuNjczIDE0LjMyNyAzMiAzMiAzMkg3ODcuODF6IiBwLWlkPSI4NTYwIiBmaWxsPSIjZDQyMzdhIj48L3BhdGg+PC9zdmc+
// @run-at       document-start
// @grant        GM_addStyle
// @grant        unsafeWindow
// @grant        GM_registerMenuCommand
// @grant        GM_unregisterMenuCommand
// @grant        GM_getValue
// @grant        GM_setValue
// @downloadURL https://update.greasyfork.org/scripts/482865/%E5%8D%9A%E5%AE%A2%E7%BD%91%E7%AB%99%E7%9A%84%E7%B2%BE%E7%AE%80%E5%92%8C%E5%AE%BD%E5%B1%8F%E5%A4%84%E7%90%86.user.js
// @updateURL https://update.greasyfork.org/scripts/482865/%E5%8D%9A%E5%AE%A2%E7%BD%91%E7%AB%99%E7%9A%84%E7%B2%BE%E7%AE%80%E5%92%8C%E5%AE%BD%E5%B1%8F%E5%A4%84%E7%90%86.meta.js
// ==/UserScript==

(() => {
  // src/utils/func.js
  function onLoad(func) {
    window.addEventListener("load", func, { once: true });
  }
  function watch(func, root2) {
    if (!root2)
      root2 = document.body;
    const observer = new MutationObserver((mutations) => mutations.forEach(func));
    observer.observe(root2, { childList: true, subtree: true });
    return observer;
  }
  function watchStyle(addStyle) {
    let el = addStyle();
    if (!el)
      return;
    const w = watch(() => {
      if (el.parentElement)
        return;
      el = addStyle();
    }, el.parentElement);
    onLoad(() => w.disconnect());
  }

  // src/blogs/menu.js
  var autoWidthDisabled = false;
  function initAutoWidthDisabled() {
    const key = "autoWidthDisabled";
    autoWidthDisabled = GM_getValue(key);
    let menuId = GM_registerMenuCommand(`${autoWidthDisabled ? "\u{1F532}" : "\u2705"}\u5BBD\u5C4F\u5904\u7406`, () => {
      GM_setValue("autoWidthDisabled", !autoWidthDisabled);
      GM_unregisterMenuCommand(menuId);
      initAutoWidthDisabled();
      location.reload();
    });
  }
  initAutoWidthDisabled();

  // src/blogs/webs/zhihu.js
  var zhihu = { global, zhuanlan, tardis_zm, question, topic };
  function global() {
    const loginStyle = [
      GM_addStyle(".Modal-wrapper{display:none !important}"),
      GM_addStyle("html{overflow:auto !important; margin-right: 0 !important}")
    ];
    onLoad(() => {
      document.querySelector(".signFlowModal>.Modal-closeButton")?.click();
      loginStyle.forEach((v) => v?.remove());
    });
    GM_addStyle('div[style*="margin-top: 14px"][style*="position: fixed"]{display:none !important}');
    GM_addStyle(
      'div[style*="transform-origin: center bottom"][style*="margin-top: -6px"]{display:none !important}'
    );
    onLoad(() => {
      watch((item) => {
        const token = "link.zhihu.com/?target=";
        [
          ...item.target.querySelectorAll(`a.external[href*="${token}"]`),
          ...item.target.querySelectorAll(`a.LinkCard[href*="${token}"]`)
        ].forEach((el) => {
          el.href = decodeURIComponent(el.href.slice(el.href.indexOf(token) + token.length));
        });
      });
    });
  }
  function zhuanlan() {
    GM_addStyle(".ColumnPageHeader.is-fixed{display:none !important}");
    GM_addStyle(".RichContent-actions.is-fixed{display:none !important}");
    if (!autoWidthDisabled) {
      GM_addStyle(".Post-Main{padding: 0 10px !important}");
      GM_addStyle(".Post-Header{width: auto !important}");
      GM_addStyle(".Post-RichTextContainer{width: 100% !important;}");
      GM_addStyle(".Post-RichTextContainer img{width: auto !important;}");
      GM_addStyle(".Post-RichTextContainer *{box-sizing: border-box !important;}");
      GM_addStyle(".Post-SideActions{display: none !important;}");
      GM_addStyle(
        ".Post-Sub > div{overflow: hidden !important; width: auto !important; margin-left: 10px !important;}"
      );
    }
  }
  function tardis_zm() {
    GM_addStyle(".sgui-header{display:none !important}");
    if (!autoWidthDisabled) {
      GM_addStyle(".Container{max-width:unset !important}");
      GM_addStyle(".Container>.Question-main img{width:auto !important}");
    }
  }
  function question() {
    if (!autoWidthDisabled) {
      GM_addStyle(".Question-main{width: auto !important;max-width: 100%;}");
      GM_addStyle(".Question-main > .ListShortcut{flex:1 !important; min-width:0 !important; display: flex;}");
      GM_addStyle(
        ".Question-mainColumn{flex: 1 !important; min-width:0 !important; margin-right:10px !important}"
      );
      GM_addStyle(".Question-mainColumn img{width:auto !important}");
      GM_addStyle(".AuthorInfo{max-width: none !important;}");
    }
    GM_addStyle(".AppBanner{display: none !important;}");
    GM_addStyle(".Question-mainColumnLogin{display: none !important;}");
    GM_addStyle(".AppHeader.is-fixed{display:none !important}");
    GM_addStyle(".RichContent-actions.is-fixed{display:none !important}");
    document.addEventListener("copy", (e) => e.stopPropagation(), true);
  }
  function topic() {
    if (!autoWidthDisabled) {
      GM_addStyle("#root .App-main > div:has(#TopicMain){max-width: calc(100% - 20px) !important;}");
    }
  }

  // src/blogs/webs/jianshu.js
  var jianshu = { blog };
  function blog() {
    watchStyle(() => {
      let el;
      el = GM_addStyle("footer + div{display:none !important;}");
      GM_addStyle("aside > section + div{display:none !important;}");
      if (!autoWidthDisabled) {
        GM_addStyle('div[role="main"]{width:auto !important;}');
        GM_addStyle('div[role="main"] > div:first-child{flex:1 !important;width:0 !important;}');
      }
      GM_addStyle(
        'div[role="main"] > div:first-child > section:first-child ~ section{display:none !important;}'
      );
      return el;
    });
  }

  // src/blogs/webs/51cto.js
  var cto = { blog: blog2, article };
  function blog2() {
    GM_addStyle(".recommend-video{display:none !important;}");
    GM_addStyle(".action-aside-left{display:none !important;}");
    GM_addStyle("aside.minmenu{display:none !important;}");
    document.addEventListener("copy", (e) => e.stopPropagation(), true);
    document.addEventListener("keydown", (e) => e.stopPropagation(), true);
    if (!autoWidthDisabled) {
      GM_addStyle("#page_center{width: calc(100% - 20px);display: flex;}");
      GM_addStyle("#page_center>.detail-content-left{flex: 1;margin-right: 10px;}");
    }
  }
  function article() {
    GM_addStyle(".left-window{display: none;}");
    GM_addStyle(".article-right{display: none;}");
    GM_addStyle(".suspension-pendant_r{display: none;}");
    GM_addStyle(".components-common-suspension{display: none !important;}");
    if (!autoWidthDisabled) {
      GM_addStyle(".article{width: calc(100% - 20px) !important;}");
      GM_addStyle(".article>.article-left{width: 100% !important;}");
    }
  }

  // src/blogs/webs/360doc.js
  var doc360 = { blog: blog3 };
  function blog3() {
    GM_addStyle(".doc360article_content{width:fit-content !important;padding:0 !important;}");
    document.addEventListener("scroll", (e) => e.stopPropagation(), true);
    GM_addStyle(".doc360article_content>.a_right{display:none !important;}");
    GM_addStyle("#goTop2{display:none !important;}");
    GM_addStyle(".floatqrcode{display:none !important;}");
    GM_addStyle("#divyoulikeadtitle{display:none !important;}");
    GM_addStyle("#contextmenudivmouseup{display:none !important;}");
    GM_addStyle(".atfixednav{display:none !important;}");
    document.addEventListener("copy", (e) => e.stopPropagation(), true);
    document.addEventListener("contextmenu", (e) => e.stopPropagation(), true);
    document.addEventListener("keydown", (e) => e.stopPropagation(), true);
    if (!autoWidthDisabled) {
      GM_addStyle(".doc360article_content>.a_left{width:100% !important;}");
      GM_addStyle(
        ".doc360article_content>.a_left>#bgchange{width:100% !important;padding:18px 20px 0 !important;box-sizing:border-box !important;}"
      );
      GM_addStyle("#articlecontent>table{width:100% !important;}");
      onLoad(() => {
        const ctx = document.getElementById("articlecontent");
        ctx.querySelectorAll('*[style*="max-width:"]').forEach((e) => {
          e.style.maxWidth = "unset";
        });
      });
    }
  }

  // src/blogs/webs/bilibili.js
  var bilibili = { blog: blog4 };
  function blog4() {
    onLoad(() => {
      document.querySelectorAll(".van-popover:has(> .unlogin-popover)").forEach((e) => {
        e.style.display = "none";
      });
    });
    GM_addStyle(".login-tip{display:none !important;}");
    if (!autoWidthDisabled) {
      GM_addStyle(
        ".article-detail{width:calc(100% - 90px) !important;margin-right:80px !important;}"
      );
      GM_addStyle(".right-side-bar{margin-left:0 !important;right:10px !important;}");
      GM_addStyle("#article-content{padding:0 !important;}");
    }
  }

  // src/blogs/webs/juejin.js
  var juejin = { blog: blog5 };
  function blog5() {
    GM_addStyle(".article-suspended-panel{display:none !important;}");
    GM_addStyle(".article-catalog ~ div{display:none !important;}");
    GM_addStyle(".article-catalog .catalog-body{max-height:unset !important;}");
    GM_addStyle(".bottom-login-guide{display:none !important;}");
    GM_addStyle("*:has(~ .to-top-btn){display:none !important;}");
    GM_addStyle(".global-float-banner{display:none !important;}");
    GM_addStyle(".post-bottom-right{display:none !important;}");
    GM_addStyle(".recommended-area{display:none !important;}");
    if (!autoWidthDisabled) {
      GM_addStyle(".main-container{max-width:unset !important;width:calc(100% - 30px) !important;}");
      GM_addStyle(".main-area{width:calc(100% - 25rem - 20px) !important;}");
    }
    onLoad(() => {
      const root2 = document.getElementById("article-root");
      if (!root2)
        return;
      const tokens = ["link.juejin.cn?target=", "link.juejin.cn/?target="];
      tokens.map((token) => root2.querySelectorAll(`a[href*="${token}"]`)).reduce((r, v) => [...r, ...v], []).forEach((el) => {
        for (const token of tokens) {
          const pos = el.href.indexOf(token);
          if (pos === -1)
            continue;
          el.href = decodeURIComponent(el.href.slice(pos + token.length));
          break;
        }
      });
    });
  }

  // src/blogs/webs/csdn.js
  var csdn = { global: global2, blog: blog6, wenku };
  function global2() {
    GM_addStyle(".csdn-toolbar-creative-mp{display:none !important}");
    GM_addStyle(".csdn-side-toolbar{display:none !important}");
  }
  function blog6() {
    GM_addStyle("#csdn-toolbar-profile-nologin{display:none !important}");
    GM_addStyle(".hide-article-box{display:none !important}");
    GM_addStyle("#article_content{height:auto !important}");
    GM_addStyle(".main_father .blog_container_aside{display:none !important}");
    GM_addStyle(".main_father #toolBarBox .left-toolbox{left:0 !important; width:100% !important}");
    GM_addStyle(".main_father #rightAside{display:none !important}");
    GM_addStyle(
      ".main_father #rightAsideConcision{display:block !important;margin-left:10px !important;}"
    );
    if (!autoWidthDisabled) {
      GM_addStyle(
        ".main_father #mainBox{flex:1 !important; width:0 !important; margin-right:0 !important;}"
      );
      GM_addStyle(".main_father #mainBox > main{width:100% !important}");
    } else {
      GM_addStyle(".main_father #mainBox{width:auto !important;margin-right:0 !important;}");
    }
    GM_addStyle(".tool-active-list{display:none !important}");
    GM_addStyle("#tool-share{display:none !important}");
    GM_addStyle(".passport-login-tip-container{display:none !important}");
    document.addEventListener("scroll", (e) => e.stopPropagation(), true);
    GM_addStyle("#content_views pre code{user-select:text !important}");
    GM_addStyle("#content_views pre{user-select:text !important}");
    GM_addStyle("#content_views{user-select:text !important}");
    GM_addStyle("#articleSearchTip{display:none !important}");
    onLoad(() => {
      document.querySelectorAll("code").forEach((el) => el.addEventListener("copy", (e) => e.stopPropagation(), true));
    });
    onLoad(() => {
      document.querySelectorAll('#article_content a:not([href*="csdn.net"])').forEach((el) => {
        el.addEventListener("mouseover", (e) => e.stopPropagation(), true);
        el.addEventListener("click", (e) => e.stopPropagation(), true);
      });
    });
  }
  function wenku() {
    GM_addStyle(".article-box > .cont{max-height:unset !important}");
    GM_addStyle(".article-box > .cont > .open {display:none !important}");
    GM_addStyle(".layout-right {display:none !important}");
    if (!autoWidthDisabled) {
      GM_addStyle(".layout-center {width:100% !important}");
    }
  }

  // src/blogs/webs/segmentfault.js
  var segmentfault = { global: global3, wenda, blog: blog7 };
  function global3() {
    document.addEventListener("scroll", (e) => e.stopPropagation(), true);
  }
  function wenda() {
    watchStyle(() => {
      let el;
      el = GM_addStyle("#sf-header{position:relative !important;}");
      if (!autoWidthDisabled) {
        GM_addStyle("#question-wrap{max-width:unset !important;}");
        GM_addStyle("#questionMain .functional-area-left{display:none !important;}");
        GM_addStyle("#questionMain+.right-side{display:none !important;}");
      }
      return el;
    });
  }
  function blog7() {
    watchStyle(() => {
      let el;
      if (!autoWidthDisabled) {
        el = GM_addStyle(".article-wrap{max-width:unset !important;}");
        GM_addStyle(".article-wrap .row>div:has(.article.article-content ){flex:1;}");
        GM_addStyle(".article-wrap .row>div:has(>.functional-area-left){display:none !important;}");
        GM_addStyle(".article-wrap .row>div:has(.article.article-content )+div:not(:has(#article-nav-list)){display:none !important;}");
        GM_addStyle("#__next>.container:has(+footer){max-width:100% !important;}");
        GM_addStyle("#__next>.container:has(+footer)>.row>.mx-auto{flex:1 !important;}");
      }
      return el;
    });
  }

  // src/blogs/index.js
  var root = {
    com: {
      zhihu: {
        func: zhihu.global,
        zhuanlan: {
          func: zhihu.zhuanlan
        },
        www: {
          question: {
            func: zhihu.question
          },
          tardis: {
            zm: {
              func: zhihu.tardis_zm
            }
          },
          topic: {
            func: zhihu.topic
          }
        }
      },
      jianshu: {
        www: {
          p: {
            func: jianshu.blog
          }
        }
      },
      "51cto": {
        blog: {
          func: cto.blog
        },
        www: {
          article: {
            func: cto.article
          }
        }
      },
      "360doc": {
        www: {
          content: {
            func: doc360.blog
          }
        }
      },
      bilibili: {
        www: {
          read: {
            func: bilibili.blog
          }
        }
      },
      segmentfault: {
        func: segmentfault.global,
        q: {
          func: segmentfault.wenda
        },
        a: {
          func: segmentfault.blog
        }
      }
    },
    cn: {
      juejin: {
        post: {
          func: juejin.blog
        }
      }
    },
    net: {
      csdn: {
        func: csdn.global,
        blog: {
          func: csdn.blog
        },
        wenku: {
          func: csdn.wenku
        }
      }
    }
  };
  function exec(route, paths2) {
    const item = route[paths2[0]];
    const func = route.func;
    paths2 = paths2.slice(1);
    let rc = true;
    if (item) {
      rc = exec(item, paths2) !== false;
    }
    if (rc && func) {
      rc = func() !== false;
    }
    return rc;
  }
  var paths = unsafeWindow.location.pathname.split("/").slice(1);
  var domains = unsafeWindow.location.hostname.split(".");
  exec(root, [...domains.reverse(), ...paths]);
})();
